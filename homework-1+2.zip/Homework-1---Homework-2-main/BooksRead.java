public class BooksRead {
    //Initializers
    double totalRead;
    String genreOfBooks;
    boolean skimmed;

    //Constructors
    public BooksRead(double totalRead, String genreOfBooks, boolean skimmed) {
        this.totalRead = totalRead;
        this.genreOfBooks = genreOfBooks;
        this.skimmed = skimmed;
    }
}


