public interface IChallenge {
    //Methods
    double averagePerDay();
    double differenceFromGoal();
}
